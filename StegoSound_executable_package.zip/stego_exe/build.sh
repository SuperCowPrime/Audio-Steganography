#!/bin/bash
# ============================================================
#  build.sh — Build StegoSound binary (macOS / Linux)
#  Run this ONCE. The resulting binary needs NO Python.
# ============================================================

set -e

echo ""
echo "  ============================================"
echo "   StegoSound — Build Script (macOS/Linux)"
echo "  ============================================"
echo ""

# 1. Check Python
if ! command -v python3 &>/dev/null; then
    echo "  [ERROR] python3 not found."
    exit 1
fi

# 2. Install dependencies
echo "  [1/3] Installing dependencies..."
pip3 install flask numpy scipy PyWavelets Pillow pyinstaller --quiet

# 3. Build
echo "  [2/3] Bundling (this takes 1-2 minutes)..."
pyinstaller StegoSound.spec --clean --noconfirm

# 4. Done
echo ""
echo "  [3/3] Done!"
echo ""
echo "  ============================================"
echo "   Output: dist/StegoSound"
echo "   Run:    ./dist/StegoSound"
echo "  ============================================"
echo ""
