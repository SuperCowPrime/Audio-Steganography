# StegoSound.spec
# Run:  pyinstaller StegoSound.spec
# Output: dist/StegoSound.exe  (Windows)
#         dist/StegoSound      (macOS/Linux)

import os

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        # Bundle the HTML template
        ('templates', 'templates'),
        # Bundle the steganography library
        ('audio_steganography.py', '.'),
    ],
    hiddenimports=[
        'flask',
        'werkzeug',
        'werkzeug.serving',
        'werkzeug.routing',
        'jinja2',
        'click',
        'numpy',
        'scipy',
        'scipy.io',
        'scipy.io.wavfile',
        'pywt',
        'PIL',
        'PIL.Image',
        'pkg_resources.py2_compat',
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        'tkinter', 'matplotlib', 'pandas', 'IPython',
        'pytest', 'sphinx', 'docutils',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='StegoSound',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,          # show console window so users can see status
    icon=None,             # add icon=r'icon.ico' if you have one
)
