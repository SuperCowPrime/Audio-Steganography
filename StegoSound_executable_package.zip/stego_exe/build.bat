@echo off
REM ============================================================
REM  build.bat — Build StegoSound.exe
REM  Run this ONCE on a Windows machine with Python installed.
REM  The resulting StegoSound.exe needs NO Python to run.
REM ============================================================

echo.
echo  ============================================
echo   StegoSound — Build Script
echo  ============================================
echo.

REM 1. Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Install from https://python.org
    pause
    exit /b 1
)

REM 2. Install dependencies
echo  [1/3] Installing dependencies...
pip install flask numpy scipy PyWavelets Pillow pyinstaller --quiet
if errorlevel 1 (
    echo  [ERROR] pip install failed.
    pause
    exit /b 1
)

REM 3. Run PyInstaller
echo  [2/3] Bundling into .exe (this takes 1-2 minutes)...
pyinstaller StegoSound.spec --clean --noconfirm
if errorlevel 1 (
    echo  [ERROR] PyInstaller failed.
    pause
    exit /b 1
)

REM 4. Done
echo.
echo  [3/3] Done!
echo.
echo  ============================================
echo   Output: dist\StegoSound.exe
echo   Double-click it to launch the app.
echo  ============================================
echo.
pause
