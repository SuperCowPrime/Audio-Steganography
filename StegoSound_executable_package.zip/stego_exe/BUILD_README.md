# StegoSound — Executable Build

## For end users (no Python needed)

1. Get `StegoSound.exe` from whoever built it
2. Double-click it
3. A browser tab opens at `http://localhost:5000` automatically
4. Close the console window to stop the server

Stego-audio output files are saved in an `outputs/` folder
next to the `.exe`.

---

## For developers — building the .exe yourself

You need Python 3.9+ installed on your machine (only for the build step).

### Windows
```
build.bat
```

### macOS / Linux
```
chmod +x build.sh
./build.sh
```

The build takes ~1-2 minutes. The result is `dist/StegoSound.exe`
(Windows) or `dist/StegoSound` (macOS/Linux).

---

## File structure

```
stego_web_app/
├── main.py                  ← launcher (Flask + auto-browser)
├── audio_steganography.py   ← core steganography library
├── StegoSound.spec          ← PyInstaller config
├── build.bat                ← Windows build script
├── build.sh                 ← macOS/Linux build script
├── templates/
│   └── index.html           ← the web UI
└── outputs/                 ← stego files saved here
```
