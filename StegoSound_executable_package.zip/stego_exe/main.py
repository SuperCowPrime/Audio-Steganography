"""
StegoSound — Audio Steganography App
=====================================
Double-click to run. Opens in your browser automatically.
No Python installation required.
"""

import sys
import os
import threading
import webbrowser
import time
import tempfile
import shutil

# ── PyInstaller: fix paths so templates/uploads/outputs work from the .exe ──
if getattr(sys, 'frozen', False):
    # Running as a PyInstaller bundle
    BASE_DIR = sys._MEIPASS          # read-only: bundled files (templates etc.)
    # Use a writable folder next to the .exe for uploads/outputs
    EXE_DIR  = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    EXE_DIR  = BASE_DIR

UPLOAD_DIR = os.path.join(EXE_DIR, 'uploads')
OUTPUT_DIR = os.path.join(EXE_DIR, 'outputs')
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

PORT = 5000

# ── Import Flask app and patch its config ───────────────────────────────────
# We import app from the bundled app.py but override folder paths
import importlib, types

# Make sure the bundled modules are importable
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from flask import Flask, render_template, request, jsonify, send_file
import numpy as np
from io import BytesIO
from scipy.io import wavfile
from PIL import Image as PILImage
import uuid, base64, traceback
import audio_steganography as stego

# ── Flask app (self-contained, no template folder dependency issues) ─────────
app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, 'templates'),
    static_folder=None,
)
app.config['SECRET_KEY']         = 'stego-secret-2024'
app.config['UPLOAD_FOLDER']      = UPLOAD_DIR
app.config['OUTPUT_FOLDER']      = OUTPUT_DIR
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

ALLOWED_EXTENSIONS = {'wav'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_audio(filepath):
    sample_rate, audio = wavfile.read(filepath)
    if audio.dtype == np.int16:
        audio = audio.astype(np.float64) / 32768.0
    elif audio.dtype == np.int32:
        audio = audio.astype(np.float64) / 2147483648.0
    elif audio.dtype == np.float32:
        audio = audio.astype(np.float64)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    return sample_rate, audio

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/test', methods=['GET'])
def test():
    return jsonify({'status': 'ok', 'message': 'Server is running!'})

@app.route('/api/encode', methods=['POST'])
def encode():
    try:
        if 'carrier_audio' not in request.files:
            return jsonify({'error': 'Carrier audio is required'}), 400
        carrier_file = request.files['carrier_audio']
        if carrier_file.filename == '' or not allowed_file(carrier_file.filename):
            return jsonify({'error': 'Only WAV files allowed'}), 400

        data_type = request.form.get('data_type', 'text')
        protocol  = request.form.get('protocol', 'addition')

        temp_id      = uuid.uuid4().hex
        carrier_path = os.path.join(app.config['UPLOAD_FOLDER'], f'carrier_{temp_id}.wav')
        carrier_file.save(carrier_path)
        sample_rate, carrier_audio = load_audio(carrier_path)

        henon_params = {
            'x0': float(request.form.get('henon_x0', 0.01)),
            'x1': float(request.form.get('henon_x1', 0.02)),
            'a':  float(request.form.get('henon_a',  0.3)),
            'b':  float(request.form.get('henon_b',  1.4)),
        }
        arnold_iterations = int(request.form.get('arnold_iterations', 5))
        alpha             = float(request.form.get('alpha', 0.05))

        if data_type == 'text':
            secret_data = request.form.get('secret_text', '')
            if not secret_data.strip():
                os.remove(carrier_path)
                return jsonify({'error': 'Secret text is required'}), 400
        else:
            if 'secret_image' not in request.files:
                os.remove(carrier_path)
                return jsonify({'error': 'Secret image is required'}), 400
            img         = PILImage.open(request.files['secret_image']).convert('L')
            secret_data = np.array(img, dtype=np.uint8)

        if protocol == 'addition':
            stego_audio = stego.embed_addition(
                carrier_audio, secret_data,
                alpha=alpha, henon_params=henon_params,
                arnold_iterations=arnold_iterations)
        else:
            stego_audio = stego.embed_override(
                carrier_audio, secret_data,
                henon_params=henon_params,
                arnold_iterations=arnold_iterations)

        output_filename = f'stego_{protocol}_{temp_id}.wav'
        output_path     = os.path.join(app.config['OUTPUT_FOLDER'], output_filename)
        stego_int16     = (stego_audio * 32768).clip(-32768, 32767).astype(np.int16)
        wavfile.write(output_path, sample_rate, stego_int16)
        os.remove(carrier_path)

        return jsonify({
            'success':      True,
            'download_url': f'/api/download/{output_filename}',
            'protocol':     protocol,
            'data_type':    data_type,
        })
    except Exception as e:
        print(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@app.route('/api/decode', methods=['POST'])
def decode():
    try:
        if 'stego_audio' not in request.files:
            return jsonify({'error': 'Stego-audio is required'}), 400
        stego_file = request.files['stego_audio']
        if stego_file.filename == '':
            return jsonify({'error': 'No stego-audio selected'}), 400

        protocol = request.form.get('protocol', 'override')
        temp_id  = uuid.uuid4().hex
        stego_path = os.path.join(app.config['UPLOAD_FOLDER'], f'stego_{temp_id}.wav')
        stego_file.save(stego_path)
        _, stego_audio = load_audio(stego_path)

        carrier_audio = None
        if protocol == 'addition':
            if 'original_carrier' not in request.files or request.files['original_carrier'].filename == '':
                os.remove(stego_path)
                return jsonify({'error': 'Addition protocol requires original carrier audio!'}), 400
            carrier_path = os.path.join(app.config['UPLOAD_FOLDER'], f'carrier_{temp_id}.wav')
            request.files['original_carrier'].save(carrier_path)
            _, carrier_audio = load_audio(carrier_path)
            os.remove(carrier_path)

        henon_params = {
            'x0': float(request.form.get('henon_x0', 0.01)),
            'x1': float(request.form.get('henon_x1', 0.02)),
            'a':  float(request.form.get('henon_a',  0.3)),
            'b':  float(request.form.get('henon_b',  1.4)),
        }
        arnold_iterations = int(request.form.get('arnold_iterations', 5))

        if protocol == 'addition':
            recovered = stego.decode_addition(
                stego_audio, carrier_audio,
                henon_params=henon_params, arnold_iterations=arnold_iterations)
        else:
            recovered = stego.decode_override(
                stego_audio,
                henon_params=henon_params, arnold_iterations=arnold_iterations)

        os.remove(stego_path)

        if isinstance(recovered, np.ndarray):
            img    = PILImage.fromarray(recovered.astype(np.uint8))
            buf    = BytesIO()
            img.save(buf, format='PNG')
            return jsonify({
                'success':    True,
                'data_type':  'image',
                'image_data': f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}",
            })
        else:
            return jsonify({'success': True, 'data_type': 'text', 'decoded_text': recovered})

    except Exception as e:
        print(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@app.route('/api/download/<filename>')
def download_file(filename):
    filepath = os.path.join(app.config['OUTPUT_FOLDER'], filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True, download_name=filename)
    return jsonify({'error': 'File not found'}), 404

# ── Startup: open browser once Flask is ready ────────────────────────────────
def open_browser():
    time.sleep(1.5)           # give Flask a moment to bind
    webbrowser.open(f'http://localhost:{PORT}')

def main():
    print('=' * 55)
    print('  🎵  StegoSound — Audio Steganography App')
    print(f'  📍  Opening http://localhost:{PORT} …')
    print('  ✖   Close this window to stop the server.')
    print('=' * 55)

    t = threading.Thread(target=open_browser, daemon=True)
    t.start()

    # use_reloader=False is required when running inside PyInstaller
    app.run(host='127.0.0.1', port=PORT, debug=False, use_reloader=False)

if __name__ == '__main__':
    main()
