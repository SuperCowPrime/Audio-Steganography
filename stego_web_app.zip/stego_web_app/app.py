import os
import uuid
import base64
import traceback
import numpy as np
from io import BytesIO
from flask import Flask, render_template, request, jsonify, send_file
from scipy.io import wavfile
from werkzeug.utils import secure_filename
from PIL import Image as PILImage

import audio_steganography as stego

app = Flask(__name__)
app.config['SECRET_KEY'] = 'stego-secret-2024'
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['OUTPUT_FOLDER'] = 'outputs/'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'wav'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_audio(filepath):
    sample_rate, audio = wavfile.read(filepath)
    
    if audio.dtype == np.int16:
        audio = audio.astype(np.float64) / 32768.0
    elif audio.dtype == np.int32:
        audio = audio.astype(np.float64) / 2147483648.0
    elif audio.dtype == np.float32:
        audio = audio.astype(np.float64)
    
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    
    return sample_rate, audio

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/test', methods=['GET'])
def test():
    return jsonify({'status': 'ok', 'message': 'Server is running!'})

@app.route('/api/encode', methods=['POST'])
def encode():
    try:
        print("\n" + "="*50)
        print("ENCODE request received")
        
        if 'carrier_audio' not in request.files:
            return jsonify({'error': 'Carrier audio is required'}), 400
        
        carrier_file = request.files['carrier_audio']
        if carrier_file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(carrier_file.filename):
            return jsonify({'error': 'Only WAV files allowed'}), 400
        
        data_type = request.form.get('data_type', 'text')
        protocol = request.form.get('protocol', 'addition')
        print(f"Data type: {data_type}, Protocol: {protocol}")
        
        temp_id = uuid.uuid4().hex
        carrier_path = os.path.join(app.config['UPLOAD_FOLDER'], f"carrier_{temp_id}.wav")
        carrier_file.save(carrier_path)
        
        sample_rate, carrier_audio = load_audio(carrier_path)
        
        henon_params = {
            "x0": float(request.form.get('henon_x0', 0.01)),
            "x1": float(request.form.get('henon_x1', 0.02)),
            "a": float(request.form.get('henon_a', 0.3)),
            "b": float(request.form.get('henon_b', 1.4))
        }
        arnold_iterations = int(request.form.get('arnold_iterations', 5))
        alpha = float(request.form.get('alpha', 0.05))
        
        if data_type == 'text':
            secret_data = request.form.get('secret_text', '')
            if not secret_data.strip():
                os.remove(carrier_path)
                return jsonify({'error': 'Secret text is required'}), 400
        else:
            if 'secret_image' not in request.files:
                os.remove(carrier_path)
                return jsonify({'error': 'Secret image is required'}), 400
            
            image_file = request.files['secret_image']
            img = PILImage.open(image_file).convert('L')
            secret_data = np.array(img, dtype=np.uint8)
        
        if protocol == 'addition':
            stego_audio = stego.embed_addition(
                carrier_audio, secret_data,
                alpha=alpha,
                henon_params=henon_params,
                arnold_iterations=arnold_iterations
            )
        else:
            stego_audio = stego.embed_override(
                carrier_audio, secret_data,
                henon_params=henon_params,
                arnold_iterations=arnold_iterations
            )
        
        output_filename = f"stego_{protocol}_{temp_id}.wav"
        output_path = os.path.join(app.config['OUTPUT_FOLDER'], output_filename)
        stego_int16 = (stego_audio * 32768).clip(-32768, 32767).astype(np.int16)
        wavfile.write(output_path, sample_rate, stego_int16)
        
        os.remove(carrier_path)
        
        return jsonify({
            'success': True,
            'download_url': f'/api/download/{output_filename}',
            'protocol': protocol,
            'data_type': data_type
        })
        
    except Exception as e:
        print(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@app.route('/api/decode', methods=['POST'])
def decode():
    try:
        print("\n" + "="*50)
        print("DECODE request received")
        
        if 'stego_audio' not in request.files:
            return jsonify({'error': 'Stego-audio is required'}), 400
        
        stego_file = request.files['stego_audio']
        if stego_file.filename == '':
            return jsonify({'error': 'No stego-audio selected'}), 400
        
        protocol = request.form.get('protocol', 'override')
        print(f"Decoding protocol: {protocol}")
        
        temp_id = uuid.uuid4().hex
        stego_path = os.path.join(app.config['UPLOAD_FOLDER'], f"stego_{temp_id}.wav")
        stego_file.save(stego_path)
        
        _, stego_audio = load_audio(stego_path)
        
        carrier_audio = None
        if protocol == 'addition':
            if 'original_carrier' not in request.files:
                os.remove(stego_path)
                return jsonify({'error': 'Addition protocol requires original carrier audio!'}), 400
            
            carrier_file = request.files['original_carrier']
            if not carrier_file or carrier_file.filename == '':
                os.remove(stego_path)
                return jsonify({'error': 'Addition protocol requires original carrier audio!'}), 400
            
            carrier_path = os.path.join(app.config['UPLOAD_FOLDER'], f"carrier_{temp_id}.wav")
            carrier_file.save(carrier_path)
            _, carrier_audio = load_audio(carrier_path)
            os.remove(carrier_path)
        
        henon_params = {
            "x0": float(request.form.get('henon_x0', 0.01)),
            "x1": float(request.form.get('henon_x1', 0.02)),
            "a": float(request.form.get('henon_a', 0.3)),
            "b": float(request.form.get('henon_b', 1.4))
        }
        arnold_iterations = int(request.form.get('arnold_iterations', 5))
        
        if protocol == 'addition':
            recovered = stego.decode_addition(
                stego_audio, carrier_audio,
                henon_params=henon_params,
                arnold_iterations=arnold_iterations
            )
        else:
            recovered = stego.decode_override(
                stego_audio,
                henon_params=henon_params,
                arnold_iterations=arnold_iterations
            )
        
        os.remove(stego_path)
        
        if isinstance(recovered, np.ndarray):
            img = PILImage.fromarray(recovered.astype(np.uint8))
            buffer = BytesIO()
            img.save(buffer, format='PNG')
            img_base64 = base64.b64encode(buffer.getvalue()).decode()
            
            return jsonify({
                'success': True,
                'data_type': 'image',
                'image_data': f'data:image/png;base64,{img_base64}'
            })
        else:
            return jsonify({
                'success': True,
                'data_type': 'text',
                'decoded_text': recovered
            })
        
    except Exception as e:
        print(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@app.route('/api/download/<filename>')
def download_file(filename):
    filepath = os.path.join(app.config['OUTPUT_FOLDER'], filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True, download_name=filename)
    return jsonify({'error': 'File not found'}), 404

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Audio Steganography Web App")
    print("📍 Open http://localhost:5000")
    print("📍 Supports TEXT and IMAGE hiding")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=5000)